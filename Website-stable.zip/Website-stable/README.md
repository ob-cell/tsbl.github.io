# DBots - Website
Quickly and easily find Discord bots. Use this repository to customize the website.

![Discord](https://img.shields.io/discord/236608364333891585?color=6ca294&amp;label=Support&amp;style=for-the-badge)
![Lines of Code](https://img.shields.io/tokei/lines/github/DBots-co/Website?color=6ca294&style=for-the-badge)
![Repo Stars](https://img.shields.io/github/stars/DBots-co/Website?color=6ca294&style=for-the-badge)

![Website Preview](https://i.ibb.co/mJKfRLK/image.png)

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/dbots-co/api)

## Setup
https://help.codea.live/projects/dbots
