import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bot-settings',
  templateUrl: './bot-settings.component.html',
  styleUrls: ['./bot-settings.component.css']
})
export class BotSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
