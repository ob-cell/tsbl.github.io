import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bot-log',
  templateUrl: './bot-log.component.html',
  styleUrls: ['./bot-log.component.css']
})
export class BotLogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
