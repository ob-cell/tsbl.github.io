import { TruncatedPipe } from './truncated.pipe';

describe('TruncatedPipe', () => {
  it('create an instance', () => {
    const pipe = new TruncatedPipe();
    expect(pipe).toBeTruthy();
  });
});
