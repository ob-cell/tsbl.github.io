# Credits

## <i class="fas fa-code text-primary"></i> API
ADAMJR
## <i class="fas fa-star text-secondary"></i> Icons
PaPi
