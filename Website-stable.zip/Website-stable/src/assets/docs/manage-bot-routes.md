<title>Manage Bot API</title>
<description>Manage bots with DBots through HTTP requests.</description>
<url>manage-bots-api</url>

# Manage Bots API

## 