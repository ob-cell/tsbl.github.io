<title>How It Works</title>
<description>How algorithms work on DBots, and more.</description>
<url>how-it-works</url>

# How It Works
All searched bots are ranked by the most votes.

## New Bots
Bots less than one week old, ranked by the most votes.

## Searching
`Overview`, `Body` and `Tags`, in order of use, are used to display results.

To best results make sure to optimize these fields with keywords etc.