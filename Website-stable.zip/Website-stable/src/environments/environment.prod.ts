export const environment = {
  production: true,
  endpoint: '/api/v1',
  rootEndpoint: 'http://localhost:3000',
  discordInvite: 'https://discord.gg/uDTgxyg',
  docsURL: 'https://docs.dbots.co',
  githubURL: 'https://github.com/DBots-co',
  version: 'v1.0.3b',
  url: 'https://dbots.co',
  guildId: '236608364333891585'
};
